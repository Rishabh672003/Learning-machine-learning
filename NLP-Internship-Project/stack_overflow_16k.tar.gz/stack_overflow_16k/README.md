This dataset is an extract from the public [Stack Overflow dataset](https://console.cloud.google.com/marketplace/details/stack-exchange/stack-overflow) for use as a tutorial on tensorflow.org. 

It contains the body of 16,000 posts on four languages (Java, Python, CSharp, and Javascript), which are equally divided into train and test. 

The keywords "Java", "Python", "CSharp" and "JavaScript" have been replaced in each post by the word "BLANK" in order to increase the difficulty of this dataset in classification examples.

